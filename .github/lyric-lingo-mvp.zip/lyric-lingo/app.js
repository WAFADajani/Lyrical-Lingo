
// LyricLingo — MVP (no external APIs).
// Loads a demo rap-style French "song" (original text) with per-line translation.
// Features: word tap-to-translate tooltip, highlight unknown words, quiz mode, flashcards.

const el = (sel) => document.querySelector(sel);
const els = (sel) => Array.from(document.querySelectorAll(sel));
let SONG = null;
let vocabEntries = []; // [{word, gloss}]

async function loadSong(url) {
  const res = await fetch(url);
  SONG = await res.json();
  renderStudy();
  buildFlashcards();
  newQuiz();
}

function tokenize(text) {
  // simple tokenizer: split on spaces, keep punctuation attached for display, but map to base for lookup
  const tokens = text.split(/(\s+)/);
  return tokens.map(t => ({ raw: t, base: t.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^\p{L}0-9']/gu, '') }));
}

function lookup(base) {
  if (!base) return null;
  return SONG.dictionary[base] || null;
}

function renderStudy() {
  el('#studyPanel').classList.remove('hidden');
  el('#quizPanel').classList.add('hidden');
  el('#flashcardPanel').classList.add('hidden');
  el('#lyrics').innerHTML = '';

  SONG.lines.forEach((lineObj, idx) => {
    const lineDiv = document.createElement('div');
    lineDiv.className = 'lyric-line';
    const lineSpan = document.createElement('div');

    const tokens = tokenize(lineObj.fr);
    tokens.forEach(tok => {
      if (tok.raw.trim() === '') { lineSpan.append(tok.raw); return; }
      const span = document.createElement('span');
      span.className = 'token';
      const info = lookup(tok.base);
      if (!info && el('#highlightUnknown').checked) span.classList.add('unknown');
      span.textContent = tok.raw;
      span.addEventListener('mouseenter', (e) => showTooltip(e, tok.base));
      span.addEventListener('mouseleave', hideTooltip);
      span.addEventListener('click', (e) => showTooltip(e, tok.base));
      lineSpan.appendChild(span);
    });

    lineDiv.appendChild(lineSpan);
    const showTrans = el('#showTranslation').checked;
    const tr = document.createElement('div');
    tr.className = 'lyric-translation';
    tr.textContent = showTrans ? lineObj.en : ' ';
    if (!showTrans) tr.classList.add('hidden');
    lineDiv.appendChild(tr);
    el('#lyrics').appendChild(lineDiv);
  });
}

function showTooltip(evt, base) {
  const tip = el('#tooltip');
  const def = lookup(base);
  if (!def) {
    tip.textContent = 'No entry yet — add to dictionary';
  } else {
    tip.innerHTML = `<strong>${def.head || base}</strong>${def.pron ? ' · ' + def.pron : ''}<br>${def.gloss}${def.notes ? '<br><em>' + def.notes + '</em>' : ''}`;
  }
  tip.classList.remove('hidden');
  const rect = evt.target.getBoundingClientRect();
  tip.style.left = (rect.left + window.scrollX) + 'px';
  tip.style.top = (rect.bottom + window.scrollY + 8) + 'px';
}

function hideTooltip() {
  const tip = el('#tooltip');
  tip.classList.add('hidden');
}

// QUIZ MODE
function newQuiz() {
  // build blanks for every Nth non-stopword token
  const N = 6;
  const stop = new Set(SONG.stopwords);
  const quizDiv = el('#quiz');
  quizDiv.innerHTML = '';

  SONG.lines.forEach(lineObj => {
    const wrapper = document.createElement('div');
    wrapper.className = 'lyric-line';
    const tokens = tokenize(lineObj.fr);
    let count = 0;
    tokens.forEach(tok => {
      if (tok.raw.trim() === '') { wrapper.append(tok.raw); return; }
      const info = lookup(tok.base);
      const isWord = /[\p{L}]/u.test(tok.base);
      if (isWord && !stop.has(tok.base) && (count++ % N === 0)) {
        const input = document.createElement('input');
        input.type = 'text';
        input.dataset.answer = tok.raw;
        input.placeholder = '...';
        wrapper.appendChild(input);
      } else {
        wrapper.append(tok.raw);
      }
    });
    quizDiv.appendChild(wrapper);
  });
  el('#quizScore').textContent = '';
}

function checkAnswers() {
  const inputs = els('#quiz input');
  let correct = 0;
  inputs.forEach(inp => {
    const user = inp.value.trim();
    const ans = inp.dataset.answer.trim();
    if (user.localeCompare(ans, undefined, { sensitivity: 'base' }) === 0) {
      inp.classList.remove('incorrect');
      inp.classList.add('correct');
      correct++;
    } else {
      inp.classList.remove('correct');
      inp.classList.add('incorrect');
    }
  });
  el('#quizScore').textContent = `Score: ${correct} / ${inputs.length}`;
}

function renderQuiz() {
  el('#studyPanel').classList.add('hidden');
  el('#quizPanel').classList.remove('hidden');
  el('#flashcardPanel').classList.add('hidden');
}

// FLASHCARDS
function buildFlashcards() {
  vocabEntries = Object.entries(SONG.dictionary)
    .map(([base, v]) => ({ word: v.head || base, gloss: v.gloss }))
    .sort((a,b) => a.word.localeCompare(b.word));
  currentCard = 0;
  showCard(0);
}

let currentCard = 0;
function showCard(i) {
  if (!vocabEntries.length) {
    el('#flashcard .front').textContent = 'No vocabulary yet.';
    el('#flashcard .back').textContent = '';
    return;
  }
  currentCard = (i + vocabEntries.length) % vocabEntries.length;
  el('#flashcard .front').textContent = vocabEntries[currentCard].word;
  el('#flashcard .back').textContent = vocabEntries[currentCard].gloss;
  el('#flashcard .back').classList.add('hidden');
}

function renderFlashcards() {
  el('#studyPanel').classList.add('hidden');
  el('#quizPanel').classList.add('hidden');
  el('#flashcardPanel').classList.remove('hidden');
}

document.addEventListener('DOMContentLoaded', () => {
  loadSong(el('#songSelect').value);

  el('#songSelect').addEventListener('change', (e) => loadSong(e.target.value));
  el('#showTranslation').addEventListener('change', renderStudy);
  el('#highlightUnknown').addEventListener('change', renderStudy);

  el('#studyModeBtn').addEventListener('click', renderStudy);
  el('#quizModeBtn').addEventListener('click', () => { renderQuiz(); newQuiz(); });
  el('#flashcardModeBtn').addEventListener('click', renderFlashcards);

  el('#checkAnswersBtn').addEventListener('click', checkAnswers);
  el('#newQuizBtn').addEventListener('click', newQuiz);

  el('#flipCard').addEventListener('click', () => el('#flashcard .back').classList.toggle('hidden'));
  el('#nextCard').addEventListener('click', () => showCard(currentCard + 1));
  el('#prevCard').addEventListener('click', () => showCard(currentCard - 1));
});
